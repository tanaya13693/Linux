
#!/bin/bash

tar -cvzf backup.tar.gz /home/parth/linuxCourse/Linux/bashScripts

