#!/bin/bash

echo "Hello World!"
mkdir ~/Desktop/magic
cd ~/Desktop/magic
touch file{1..2}.txt
#ls -lh ~/Desktop/magic > ~/Desktop/magic.log
