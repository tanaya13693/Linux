#!/bin/bash

echo "Hello World!"
mkdir ~/Desktop/magic1
cd ~/Desktop/magic1
touch file{1..2}.txt
ls -lh ~/Desktop/magic1 > ~/Desktop/magic/logs.log
